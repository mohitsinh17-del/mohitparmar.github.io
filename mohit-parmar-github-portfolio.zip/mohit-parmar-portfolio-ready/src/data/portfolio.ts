// Edit your personal details here — every section reads from this file.
import car from "@/assets/project-car.jpg";
import robot from "@/assets/project-robot.jpg";

export const profile = {
  name: "Mohit Parmar",
  initials: "MP",
  title: "Mechanical Engineering Student | Mechanical Design | CAD | Thermal Engineering",
  intro:
    "I am pursuing a B.Tech in Mechanical Engineering at BVM College. My interests include mechanical design, CAD modelling, automotive systems, and thermal engineering. I enjoy learning through practical projects, fabrication, and industrial exposure.",
  email: "pravinsinh8827@gmail.com",
  phone: "7698685204",
  linkedin: "", // add your LinkedIn URL
  github: "", // add your GitHub URL
  resume: "", // put resume.pdf in /public and set to "/resume.pdf"
};

export const nav = ["Home", "About", "Education", "Skills", "Projects", "Experience", "Contact"];

export const about = {
  text: "I am a B.Tech Mechanical Engineering student at BVM College, interested in mechanical design, CAD modelling, automotive systems, and thermal engineering. My academic projects and industrial exposure have helped me develop practical understanding of fabrication, assembly, mechanical systems, and power plant operations. I look forward to applying my engineering knowledge, improving my technical skills, and contributing to real-world projects.",
  highlights: [
    "Mechanical Engineering Student",
    "Interest in Design and CAD",
    "Thermal Engineering",
    "Robotics and Fabrication",
  ],
};

export const education = [
  { title: "B.Tech in Mechanical Engineering", place: "BVM College", years: "2023–2027", score: "CPI: 7.07" },
  { title: "Class 12", place: "Vidhyut Board Vidhyalaya", years: "2022–2023", score: "67.69%" },
  { title: "Class 10", place: "Vidhyut Board Vidhyalaya", years: "2020–2021", score: "85.16%" },
];

export const skills = [
  { group: "CAD and Design", items: ["AutoCAD", "Fusion 360", "Onshape", "3D Modelling", "Mechanical Design"] },
  { group: "Mechanical Engineering", items: ["Mechanical Assembly", "Fabrication", "Mechanical Systems", "Component Integration"] },
  { group: "Thermal Engineering", items: ["Thermodynamics", "Heat Transfer", "Thermal Power Plant Operations"] },
  { group: "Robotics", items: ["Mechanical Fabrication", "Component Assembly", "Mechanical and Electrical System Integration"] },
  { group: "Soft Skills", items: ["Problem-Solving", "Teamwork", "Communication", "Quick Learning"] },
];

export const projects = [
  {
    title: "ADAS Car – Minor Project",
    image: car,
    alt: "Tubular pipe-frame car chassis made of AISI 4130 chromoly steel",
    text: "Developed an ADAS car model as a minor project with a full tubular pipe-frame structure made of AISI 4130 chromoly steel, powered by a battery and electrical components. The project provided practical exposure to car systems, component integration, and the application of mechanical and electrical engineering.",
    tags: ["Tubular Pipe Frame", "AISI 4130 Chromoly", "Automotive Systems", "Battery-Powered Systems", "Component Integration", "Mechanical Engineering"],
  },
  {
    title: "DD Robocon 2025 – Robotics Project",
    image: robot,
    alt: "Robot frame being assembled in a workshop",
    text: "Contributed to robot fabrication and assembly, including machining-related work and mechanical component fitting. Worked with the team on mechanism development and the integration of mechanical and electrical systems. This experience strengthened my understanding of robot mechanisms, teamwork, and practical problem-solving.",
    tags: ["Robotics", "Mechanical Fabrication", "Assembly", "System Integration", "Teamwork"],
  },
];

export const experience = [
  {
    title: "Thermal Power Plant Internship",
    org: "WTPS – Wanakbori Thermal Power Station",
    place: "Kheda, Gujarat",
    text: "Gained practical exposure to thermal power generation and the operation of major plant systems. Learned about coal handling, boilers, steam generation, turbines, condensers, generators, pumps, and cooling systems. Also observed equipment inspection, maintenance practices, workplace discipline, and industrial safety procedures.",
    points: ["Thermal Power Plant Operations", "Coal Handling and Steam Generation", "Boilers and Steam Turbines", "Industrial Safety", "Equipment and Maintenance Practices"],
  },
  {
    title: "DD Robocon 2025 – Robotics Experience",
    org: "College robotics team",
    place: "BVM College",
    text: "Worked with the college robotics team on robot fabrication, assembly, and mechanism development.",
    points: ["Mechanical fabrication and assembly", "Integration of mechanical and electrical components", "Understanding of robot mechanisms", "Problem-solving and teamwork"],
  },
];
