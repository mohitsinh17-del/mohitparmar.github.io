import { useState } from "react";
import { ArrowRight, Cog, ChevronDown, GraduationCap, Wrench, Flame, Bot, Users, PenTool, Briefcase, Mail, Phone, Linkedin, Github, CheckCircle2, MapPin } from "lucide-react";
import { profile, about, education, skills, projects, experience, nav } from "@/data/portfolio";
import profilePhoto from "@/assets/profile.jpg";

import { Section } from "./Section";
import { ResumeButton } from "./ResumeButton";

export function Hero() {
  const chips = ["AutoCAD", "Fusion 360", "Onshape", "Thermal", "Robotics"];
  return (
    <section id="home" className="hero-modern relative overflow-hidden">
      <div aria-hidden className="pointer-events-none absolute -top-32 -left-32 h-96 w-96 rounded-full bg-highlight/30 blur-3xl" />
      <div aria-hidden className="pointer-events-none absolute -bottom-40 right-0 h-[28rem] w-[28rem] rounded-full bg-primary-foreground/15 blur-3xl" />
      <div className="relative mx-auto grid max-w-6xl items-center gap-14 px-5 py-20 md:grid-cols-[1.15fr_1fr] md:py-28">
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary-foreground/25 bg-primary-foreground/10 px-4 py-1.5 text-xs font-medium backdrop-blur">
            <span className="h-2 w-2 animate-pulse rounded-full bg-highlight" /> Open to internships & placements
          </span>
          <h1 className="mt-6 text-5xl font-bold leading-[1.05] tracking-tight md:text-7xl">
            Hi, I'm <br />
            <span className="text-highlight">{profile.name}</span>
          </h1>
          <p className="mt-5 text-base font-medium opacity-90 md:text-lg">{profile.title}</p>
          <p className="mt-4 max-w-lg text-sm leading-relaxed opacity-75">{profile.intro}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#projects" className="group inline-flex items-center gap-2 rounded-full bg-highlight px-7 py-3.5 text-sm font-semibold text-highlight-foreground shadow-soft transition hover:-translate-y-0.5">
              View My Projects <ArrowRight size={16} className="transition group-hover:translate-x-1" />
            </a>
            <a href="#contact" className="rounded-full border border-primary-foreground/30 bg-primary-foreground/5 px-7 py-3.5 text-sm font-semibold backdrop-blur transition hover:bg-primary-foreground/15">Contact Me</a>
          </div>
          <div className="mt-10 flex flex-wrap gap-2">
            {chips.map((c) => (
              <span key={c} className="rounded-md border border-primary-foreground/20 px-3 py-1 text-xs opacity-80">{c}</span>
            ))}
          </div>
        </div>
        <div className="relative mx-auto animate-in fade-in zoom-in-95 duration-1000">
          <Cog aria-hidden className="absolute -top-10 -right-6 h-24 w-24 animate-[spin_18s_linear_infinite] text-primary-foreground/20" />
          <Cog aria-hidden className="absolute -bottom-6 -left-10 h-16 w-16 animate-[spin_12s_linear_infinite_reverse] text-highlight/60" />
          <div className="absolute inset-0 -m-6 rounded-full border border-dashed border-primary-foreground/30" />
          <div className="relative grid h-72 w-72 place-items-center rounded-full bg-gradient-to-br from-highlight to-primary-foreground/80 p-2 shadow-soft md:h-96 md:w-96">
            <div className="h-full w-full overflow-hidden rounded-full bg-background" role="img" aria-label="Portrait of Mohit Parmar">
              <img src={profilePhoto} alt="Mohit Parmar" className="h-full w-full object-cover object-top" />
            </div>
          </div>

          <div className="absolute -left-8 top-10 flex items-center gap-2 rounded-2xl bg-background/95 px-4 py-3 text-xs font-semibold text-foreground shadow-soft backdrop-blur">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-accent text-accent-foreground"><GraduationCap size={16} /></span>
            <span>B.Tech Mechanical<br /><span className="font-normal text-muted-foreground">BVM College · 2023–27</span></span>
          </div>
          <div className="absolute -right-6 bottom-12 flex items-center gap-2 rounded-2xl bg-background/95 px-4 py-3 text-xs font-semibold text-foreground shadow-soft backdrop-blur">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-highlight/30 text-highlight-foreground"><PenTool size={16} /></span>
            <span>CAD & Design<br /><span className="font-normal text-muted-foreground">Fusion 360 · Onshape</span></span>
          </div>
        </div>
      </div>
      <a href="#about" aria-label="Scroll to About" className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 animate-bounce opacity-70 md:block"><ChevronDown /></a>
    </section>
  );
}

export function About() {
  return (
    <Section id="about" eyebrow="About Me" title="Building Practical Engineering Skills">
      <div className="grid gap-10 md:grid-cols-[1.1fr_1fr] md:items-center">
        <div className="relative rounded-3xl bg-secondary p-8 md:p-10">
          <span aria-hidden className="absolute -top-6 left-8 text-7xl font-bold leading-none text-highlight">“</span>
          <p className="relative leading-relaxed text-muted-foreground">{about.text}</p>
          <div className="mt-6 flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-full bg-primary text-sm font-bold text-primary-foreground">{profile.initials}</span>
            <span className="text-sm font-semibold">{profile.name}<br /><span className="font-normal text-muted-foreground">B.Tech Mechanical · BVM College</span></span>
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {about.highlights.map((h, i) => {
            const Icon = skillIcons[i] ?? Wrench;
            return (
              <div key={h} className="group rounded-2xl border bg-card p-6 transition hover:-translate-y-1 hover:border-primary hover:shadow-soft">
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-accent text-accent-foreground transition group-hover:bg-primary group-hover:text-primary-foreground"><Icon size={20} /></span>
                <p className="mt-4 text-sm font-semibold">{h}</p>
              </div>
            );
          })}
        </div>
      </div>
    </Section>
  );
}

export function Education() {
  return (
    <Section id="education" eyebrow="Education" title="Academic Journey" muted>
      <ol className="relative mx-auto max-w-3xl border-l-2 border-dashed border-primary/30 pl-8">
        {education.map((e, i) => (
          <li key={e.title} className="relative mb-8 last:mb-0">
            <span className={`absolute -left-[3.05rem] top-5 grid h-9 w-9 place-items-center rounded-full ring-4 ring-secondary ${i === 0 ? "bg-highlight text-highlight-foreground" : "bg-primary text-primary-foreground"}`}><GraduationCap size={16} /></span>
            <div className="flex flex-col gap-4 rounded-2xl bg-card p-6 shadow-soft transition hover:-translate-y-1 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <span className="text-xs font-semibold text-primary">{e.years}</span>
                <h3 className="mt-1 text-lg font-semibold">{e.title}</h3>
                <p className="text-sm text-muted-foreground">{e.place}</p>
              </div>
              <span className="self-start rounded-full bg-accent px-4 py-2 text-sm font-bold text-accent-foreground sm:self-center">{e.score}</span>
            </div>
          </li>
        ))}
      </ol>
    </Section>
  );
}

const skillIcons = [PenTool, Wrench, Flame, Bot, Users];

export function Skills() {
  return (
    <Section id="skills" eyebrow="Skills" title="Technical Skills">
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-6">
        {skills.map((s, i) => {
          const Icon = skillIcons[i] ?? Wrench;
          const featured = i === 0;
          return (
            <div key={s.group} className={`group rounded-3xl p-7 transition hover:-translate-y-1 hover:shadow-soft ${i < 2 ? "lg:col-span-3" : "lg:col-span-2"} ${featured ? "hero-modern" : "border bg-card"}`}>
              <div className="flex items-center gap-3">
                <span className={`grid h-12 w-12 place-items-center rounded-2xl ${featured ? "bg-highlight text-highlight-foreground" : "bg-accent text-accent-foreground"}`}><Icon size={22} /></span>
                <h3 className="font-semibold">{s.group}</h3>
              </div>
              <div className="mt-5 flex flex-wrap gap-2">
                {s.items.map((it) => (
                  <span key={it} className={`rounded-full px-3 py-1.5 text-xs font-medium ${featured ? "bg-primary-foreground/15" : "bg-secondary text-secondary-foreground"}`}>{it}</span>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </Section>
  );
}

export function Projects() {
  return (
    <Section id="projects" eyebrow="Portfolio" title="Engineering Projects" muted>
      <div className="grid gap-8 md:grid-cols-2">
        {projects.map((p, i) => (
          <article key={p.title} className="group flex flex-col overflow-hidden rounded-3xl bg-card shadow-soft transition duration-300 hover:-translate-y-2">
            <div className="relative overflow-hidden">
              <img src={p.image} alt={p.alt} loading="lazy" width={1024} height={768} className="aspect-[4/3] w-full object-cover transition duration-500 group-hover:scale-105" />
              <span className="absolute left-4 top-4 rounded-full bg-background/90 px-3 py-1 text-xs font-bold text-primary backdrop-blur">0{i + 1}</span>
            </div>
            <div className="flex flex-1 flex-col p-6">
              <h3 className="text-lg font-semibold">{p.title}</h3>
              <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">{p.text}</p>
              <div className="mt-5 flex flex-wrap gap-2">
                {p.tags.map((t) => (
                  <span key={t} className="rounded-full bg-accent px-3 py-1 text-xs text-accent-foreground">{t}</span>
                ))}
              </div>
            </div>
          </article>
        ))}
      </div>
      <p className="mt-6 text-center text-xs text-muted-foreground">The project images currently included are sample visuals. Replace them with your own project photographs before publishing.</p>
    </Section>
  );
}

export function Experience() {
  return (
    <Section id="experience" eyebrow="Experience" title="Practical Exposure">
      <div className="grid gap-6 md:grid-cols-2">
        {experience.map((e, i) => (
          <div key={e.title} className="relative overflow-hidden rounded-3xl border bg-card p-8 transition hover:shadow-soft">
            <span aria-hidden className={`absolute inset-x-0 top-0 h-1.5 ${i === 0 ? "bg-highlight" : "bg-primary"}`} />
            <div className="flex items-start gap-4">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-accent text-accent-foreground">{i === 0 ? <Flame size={22} /> : <Bot size={22} />}</span>
              <div>
                <h3 className="text-lg font-semibold">{e.title}</h3>
                <p className="text-sm font-medium text-primary">{e.org}</p>
                <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground"><MapPin size={12} /> {e.place}</p>
              </div>
            </div>
            <p className="mt-5 text-sm leading-relaxed text-muted-foreground">{e.text}</p>
            <div className="mt-5 flex flex-wrap gap-2">
              {e.points.map((pt) => (
                <span key={pt} className="inline-flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1.5 text-xs"><CheckCircle2 size={13} className="text-primary" /> {pt}</span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}

function Social() {
  const items = [
    { icon: Linkedin, label: "LinkedIn", href: profile.linkedin },
    { icon: Github, label: "GitHub", href: profile.github },
  ];
  return (
    <div className="flex gap-3">
      {items.map(({ icon: Icon, label, href }) =>
        href ? (
          <a key={label} href={href} target="_blank" rel="noreferrer" aria-label={label} className="grid h-10 w-10 place-items-center rounded-full bg-primary-foreground/15 hover:bg-highlight hover:text-highlight-foreground"><Icon size={18} /></a>
        ) : (
          <span key={label} title={`${label} link coming soon`} className="grid h-10 w-10 place-items-center rounded-full bg-primary-foreground/10 opacity-60"><Icon size={18} /></span>
        ),
      )}
    </div>
  );
}

export function Contact() {
  const [note, setNote] = useState(false);
  return (
    <section id="contact" className="hero-band py-20">
      <div className="mx-auto grid max-w-6xl gap-12 px-5 md:grid-cols-2">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-highlight">Contact</p>
          <h2 className="mt-2 text-3xl font-bold md:text-4xl">Let's Connect</h2>
          <p className="mt-4 max-w-md text-sm opacity-80">Open to internships, placements, and engineering opportunities.</p>
          <div className="mt-8 space-y-4">
            <a href={`mailto:${profile.email}`} className="flex items-center gap-3 hover:text-highlight"><Mail size={18} /> {profile.email}</a>
            <a href={`tel:${profile.phone}`} className="flex items-center gap-3 hover:text-highlight"><Phone size={18} /> {profile.phone}</a>
          </div>
          <div className="mt-8 flex flex-wrap items-center gap-4"><Social /><ResumeButton /></div>
        </div>
        <form
          onSubmit={(e) => { e.preventDefault(); setNote(true); }}
          className="space-y-4 rounded-2xl bg-card p-7 text-card-foreground shadow-soft"
        >
          {["Name", "Email", "Subject"].map((f) => (
            <input key={f} required type={f === "Email" ? "email" : "text"} placeholder={f} aria-label={f} className="w-full rounded-lg border bg-background px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
          ))}
          <textarea required rows={4} placeholder="Message" aria-label="Message" className="w-full rounded-lg border bg-background px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
          <button className="w-full rounded-full bg-primary py-3 text-sm font-semibold text-primary-foreground hover:brightness-110">Send Message</button>
          <p className="text-xs text-muted-foreground">
            {note ? "This form is a demo and doesn't send messages yet — please email me directly." : "Demo form — messages aren't delivered yet. Email is the best way to reach me."}
          </p>
        </form>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="bg-foreground py-10 text-background">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-5 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="font-bold">{profile.name}</p>
          <p className="text-sm opacity-70">Mechanical Engineering Student</p>
        </div>
        <nav className="flex flex-wrap gap-4 text-sm opacity-80">
          {nav.map((n) => <a key={n} href={`#${n.toLowerCase()}`} className="hover:text-highlight">{n}</a>)}
        </nav>
        <a href={`mailto:${profile.email}`} className="text-sm hover:text-highlight">{profile.email}</a>
      </div>
      <p className="mt-8 text-center text-xs opacity-60">
        © {new Date().getFullYear()} {profile.name}. Designed with a passion for mechanical engineering and innovation.
      </p>
    </footer>
  );
}
