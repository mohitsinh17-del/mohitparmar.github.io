import type { ReactNode } from "react";

export function Section({ id, eyebrow, title, muted, children }: { id: string; eyebrow: string; title: string; muted?: boolean; children: ReactNode }) {
  return (
    <section id={id} className={muted ? "bg-secondary py-20" : "py-20"}>
      <div className="mx-auto max-w-6xl px-5">
        <div className="mb-12 text-center">
          <span className="inline-block rounded-full bg-accent px-4 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-accent-foreground">{eyebrow}</span>
          <h2 className="mt-2 text-3xl font-bold tracking-tight md:text-5xl">{title}</h2>
          <div className="mx-auto mt-4 h-1 w-12 rounded-full bg-highlight" />
        </div>
        {children}
      </div>
    </section>
  );
}
