import { Download } from "lucide-react";
import { profile } from "@/data/portfolio";

const cls = "inline-flex items-center justify-center gap-2 rounded-full bg-highlight px-5 py-2 text-sm font-semibold text-highlight-foreground transition hover:brightness-105";

export function ResumeButton() {
  if (profile.resume) {
    return <a href={profile.resume} download className={cls}><Download size={16} /> Download Resume</a>;
  }
  return (
    <span title="Resume coming soon" className={`${cls} cursor-not-allowed opacity-80`}>
      <Download size={16} /> Resume (coming soon)
    </span>
  );
}
