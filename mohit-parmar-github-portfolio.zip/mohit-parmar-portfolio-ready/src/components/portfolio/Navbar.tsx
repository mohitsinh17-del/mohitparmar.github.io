import { useState } from "react";
import { Menu, X } from "lucide-react";
import { nav, profile } from "@/data/portfolio";
import { ResumeButton } from "./ResumeButton";

export function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 bg-primary text-primary-foreground shadow-soft">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <a href="#home" className="text-lg font-bold tracking-wide">{profile.name.toUpperCase()}</a>
        <nav className="hidden items-center gap-6 text-sm lg:flex">
          {nav.map((n) => (
            <a key={n} href={`#${n.toLowerCase()}`} className="opacity-85 transition hover:text-highlight hover:opacity-100">{n}</a>
          ))}
          <ResumeButton />
        </nav>
        <button className="lg:hidden" aria-label="Toggle menu" onClick={() => setOpen(!open)}>
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <nav className="flex flex-col gap-3 border-t border-primary-foreground/20 px-5 py-4 lg:hidden">
          {nav.map((n) => (
            <a key={n} href={`#${n.toLowerCase()}`} onClick={() => setOpen(false)}>{n}</a>
          ))}
          <ResumeButton />
        </nav>
      )}
    </header>
  );
}
