import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/portfolio/Navbar";
import { Hero, About, Education, Skills, Projects, Experience, Contact, Footer } from "@/components/portfolio/Sections";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mohit Parmar — Mechanical Engineering Portfolio" },
      { name: "description", content: "Portfolio of Mohit Parmar, B.Tech Mechanical Engineering student at BVM College — CAD design, thermal engineering and robotics." },
      { property: "og:title", content: "Mohit Parmar — Mechanical Engineering Portfolio" },
      { property: "og:description", content: "CAD design, thermal engineering and robotics projects by Mohit Parmar." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <About />
        <Education />
        <Skills />
        <Projects />
        <Experience />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
