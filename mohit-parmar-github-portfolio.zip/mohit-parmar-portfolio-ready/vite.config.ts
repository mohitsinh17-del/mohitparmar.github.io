import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import tsconfigPaths from "vite-tsconfig-paths";
import { tanstackRouter } from "@tanstack/router-plugin/vite";

// GitHub Pages project sites live under /<repo-name>/, so build with:
//   VITE_BASE=/mohit-parmar-portfolio/ npm run build
// (the included GitHub Actions workflow does this automatically)
export default defineConfig({
  base: process.env.VITE_BASE || "/",
  plugins: [
    tanstackRouter({ target: "react", autoCodeSplitting: false }),
    react(),
    tailwindcss(),
    tsconfigPaths(),
  ],
  build: { outDir: "dist" },
});
