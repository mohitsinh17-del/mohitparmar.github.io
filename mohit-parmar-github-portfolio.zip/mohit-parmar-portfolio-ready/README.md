# Mohit Parmar — Mechanical Engineering Portfolio

A single-page portfolio website: blue hero band, orange accents, Poppins type, smooth-scroll
section navigation. Built with React + TypeScript + Tailwind CSS v4 + TanStack Router.

Sections: **Home · About · Education · Skills · Projects · Experience · Contact**, plus a footer.

---

## 1. Run it on your computer

You need [Node.js](https://nodejs.org) 20 or newer (npm comes with it).

```sh
npm install
npm run dev
```

Open the URL it prints (usually http://localhost:5173).

Other commands:

| Command           | What it does                                  |
| ----------------- | --------------------------------------------- |
| `npm run dev`     | Live development server with hot reload       |
| `npm run build`   | Production build into `dist/`                 |
| `npm run preview` | Serve the built `dist/` locally               |
| `npm run test`    | Run the routing test                          |

---

## 2. What's inside

```
index.html                     page shell, Poppins font link, base title/description
src/
  main.tsx                     React entry point
  router.tsx                   router + query client setup
  routeTree.gen.ts             generated route tree (don't edit by hand)
  styles.css                   ALL colours, radius, shadow, hero backgrounds
  data/portfolio.ts            ALL your text: name, intro, education, skills, projects…
  components/portfolio/
    Navbar.tsx                 sticky top bar + mobile menu
    Sections.tsx               Hero, About, Education, Skills, Projects, Experience, Contact, Footer
    Section.tsx                reusable section heading (eyebrow + title)
    ResumeButton.tsx           resume download button (greys out until a resume exists)
  assets/                      profile.jpg, project-car.jpg, project-robot.jpg
  routes/                      __root.tsx (page head/meta), index.tsx (page order)
  lib/utils.ts                 className helper
public/                        favicon.ico, robots.txt, put resume.pdf here
.github/workflows/deploy.yml   publishes the site to GitHub Pages on every push to main
```

---

## 3. Edit your details

Everything you'd normally change lives in **`src/data/portfolio.ts`** — no component edits needed:

```ts
export const profile = {
  name: "Mohit Parmar",
  title: "Mechanical Engineering Student | CAD Design | Thermal Engineering",
  intro: "…",
  email: "pravinsinh8827@gmail.com",
  phone: "7698685204",
  linkedin: "",   // paste your LinkedIn URL
  github: "",     // paste your GitHub URL
  resume: "",     // set to "/resume.pdf" after adding public/resume.pdf
};
```

- `education`, `skills`, `projects`, `experience` are plain lists — add or remove entries and the
  page updates itself.
- **Photos:** drop new files in `src/assets/` and point `projects[].image` at them
  (`import myPhoto from "@/assets/my-photo.jpg"`), or replace `src/assets/profile.jpg`
  with your own photo of the same name.
- **Resume:** put `resume.pdf` in the `public/` folder and set `resume: "/resume.pdf"` in
  `src/data/portfolio.ts`. The button turns from "coming soon" into a real download.
- **Contact form:** it is a demo — it shows a note instead of sending messages. Email is the
  working contact route. To make it send, wire it to a form service or add a server endpoint.

---

## 4. Colours and fonts

All colour values are CSS variables at the top of **`src/styles.css`** (under `:root`).
Change a value there and every section updates.

| Token                  | OKLCH (in file)               | Hex        | Where it shows up                            |
| ---------------------- | ----------------------------- | ---------- | -------------------------------------------- |
| `--primary`            | `oklch(0.52 0.2 262)`         | `#1f5ed9`  | Blue: nav bar, headings, buttons, footer text |
| `--primary-foreground` | `oklch(0.99 0 0)`             | `#fcfcfc`  | Text on blue                                  |
| `--highlight`          | `oklch(0.8 0.16 70)`          | `#fea92f`  | Orange: name, badges, CTA buttons             |
| `--highlight-foreground`| `oklch(0.25 0.05 60)`        | `#331b06`  | Text on orange                                |
| `--background`         | `oklch(1 0 0)`                | `#ffffff`  | Page background                               |
| `--foreground`         | `oklch(0.22 0.03 265)`        | `#141a29`  | Main text, footer background                  |
| `--secondary`          | `oklch(0.975 0.006 260)`      | `#f4f7fb`  | Alternating section background                |
| `--muted-foreground`   | `oklch(0.52 0.03 260)`        | `#5f6a7b`  | Secondary text                                |
| `--accent`             | `oklch(0.94 0.035 262)`       | `#dfecff`  | Light blue chips and icon tiles               |
| `--accent-foreground`  | `oklch(0.42 0.18 262)`        | `#0a41ad`  | Text inside accent chips                      |
| `--border`             | `oklch(0.92 0.01 260)`        | `#e1e5eb`  | Card borders                                  |

Hero gradient ends at `oklch(0.38 0.17 265)` (`#14359b`) inside the `hero-modern` utility.
Font: **Poppins** (400/500/600/700), loaded from Google Fonts in `index.html`.

---

## 5. Put it on GitHub

```sh
git init
git add .
git commit -m "Portfolio site"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

(On github.com: create a new empty repository first, then run the commands above in this folder.)

---

## 6. Publish it live with GitHub Pages

1. On GitHub: **Settings → Pages → Build and deployment → Source: GitHub Actions**.
2. Push to `main`. The included workflow (`.github/workflows/deploy.yml`) builds the site and
   publishes it at `https://<your-username>.github.io/<repo-name>/`.

The workflow sets `VITE_BASE=/<repo-name>/` so asset links work from a project sub-path.
Building by hand for a project page:

```sh
VITE_BASE=/<repo-name>/ npm run build
```

For a user/site root (`<username>.github.io`) or any other host (Netlify, Vercel, Cloudflare
Pages), just run `npm run build` and upload the `dist/` folder.

---

## 7. Built with

React 19 · TypeScript · Vite · Tailwind CSS v4 · TanStack Router · lucide-react icons


## Quick checklist before publishing

1. Replace `src/assets/profile.jpg` with your preferred professional photo (keep the same filename).
2. Replace `src/assets/project-car.jpg` and `src/assets/project-robot.jpg` with your actual project photographs. The current project pictures are sample visuals, not verified photographs of your own work.
3. Add your resume as `public/resume.pdf`, then change `resume: ""` to `resume: "/resume.pdf"` in `src/data/portfolio.ts`.
4. Add your real LinkedIn and GitHub profile URLs in `src/data/portfolio.ts`.
5. Review your email, phone number, education details, dates, and scores before making the site public.

### GitHub Pages deployment

Create a new GitHub repository, upload/push the contents of this project folder to its `main` branch, then open **Settings → Pages** and choose **GitHub Actions** as the deployment source. The included workflow publishes the site after the push. Your website URL will be:

`https://YOUR-GITHUB-USERNAME.github.io/REPOSITORY-NAME/`

For local testing, install Node.js 20 or newer, open a terminal in this folder, and run:

```bash
npm install
npm run dev
```

To create a production build:

```bash
npm run build
```

The contact form is currently a visual demo and does not deliver messages. Visitors can use the email link instead.
